var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["bea6a327-b0b3-4784-9986-ca1bd1c6b8bf","48a54355-933e-4b6a-8b6d-368d7ab26248"],"propsByKey":{"bea6a327-b0b3-4784-9986-ca1bd1c6b8bf":{"name":"bandido_animation","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"A.LrJwJOi3INHuxW3L6SLLdf9T5JWaI1","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/bea6a327-b0b3-4784-9986-ca1bd1c6b8bf.png"},"48a54355-933e-4b6a-8b6d-368d7ab26248":{"name":"diamante_animation","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"jswDY4aCn0xtFuRbI4hgbdOUpx2EOpsY","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/48a54355-933e-4b6a-8b6d-368d7ab26248.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


//criando o bandido e etc!
var Bandido = createSprite(195,350,20,20);
Bandido.setAnimation("bandido_animation");


var Diamante = createSprite(200,30,20,20);
Diamante.setAnimation("diamante_animation");


var Lazer1 = createSprite(1,200,10,70);
Lazer1.shapeColor="red";

var Lazer2 = createSprite(400,130,10,70);
Lazer2.shapeColor="red";

var Lazer3 = createSprite(365,395,70,10);
Lazer3.shapeColor="red";

var Lazer4 = createSprite(35,5,70,10);
Lazer4.shapeColor="red";

//Funcão de desenhar!
function draw() {
  
//Cor do fundo
background("gray");


//Tecla para iniciar o jogo
 if(keyDown("ENTER"))
  {
     Lazer1.velocityX=-5;
     Lazer2.velocityX=5;
     Lazer3.velocityY=-5;
     Lazer4.velocityY=5;
  } 
  
//teclas de movimento do bandido!
if (keyDown("up")) {
    Bandido.y=Bandido.y-5;
  }
  
if (keyDown("down")) {
    Bandido.y=Bandido.y+5;
  }
  
if (keyDown("LEFT_ARROW")) {
    Bandido.x=Bandido.x-5;
  }
  
 if (keyDown("RIGHT_ARROW")) {
    Bandido.x=Bandido.x+5;
 }


//criar paredes!
createEdgeSprites(),


//encostar e kikar!
Bandido.bounceOff(edges) ;
Bandido.isTouching(Diamante);
Bandido.isTouching(Lazer1);

Lazer1.bounceOff(edges) ;
Lazer2.bounceOff(edges) ;
Lazer3.bounceOff(edges) ;
Lazer4.bounceOff(edges) ;


//Textos de vitória e derrota!
if (Lazer1.isTouching(Bandido) || Lazer2.isTouching(Bandido) || Lazer3.isTouching(Bandido) || Lazer4.isTouching(Bandido))
{
  stroke(500);
  fill(30);
  textSize(60);
  text("Você Perdeu!",30,200);
  Lazer1.setVelocity(0,0);
  Lazer2.setVelocity(0,0);
  Lazer3.setVelocity(0,0);
  Lazer4.setVelocity(0,0);
  Bandido.setVelocity(0,0);
  }
    
 
  if (Bandido.isTouching(Diamante))
  {
  stroke(500);
  fill(30);
  textSize(50);
  text("Você Ganhou!",35,200);
  Lazer1.setVelocity(0,0);
  Lazer2.setVelocity(0,0);
  Lazer3.setVelocity(0,0);
  Lazer4.setVelocity(0,0);
  Bandido.setVelocity(0,0);
  } 


//Desenhar sprites!
drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
